#!/usr/bin/env bash
set -euo pipefail
read_secret() { tr -d '\r\n' < "/run/secrets/$1"; }

PGB_PORT="${PGBOUNCER_PORT:-6432}"
HAPROXY_RW_PORT="${HAPROXY_RW_PORT:-54322}"
POOL_MODE="${PGBOUNCER_POOL_MODE:-transaction}"
MAX_CLIENT_CONN="${PGBOUNCER_MAX_CLIENT_CONN:-2000}"
DEFAULT_POOL_SIZE="${PGBOUNCER_DEFAULT_POOL_SIZE:-40}"
AUTH_USER="${PGBOUNCER_AUTH_USER:-pgbouncer_auth}"
STORE_SPEC="${STORE_SPEC:-}"

AUTH_PASS="$(read_secret pg_pgbouncer_pass)"
REPMGR_PASS="$(read_secret pg_repmgr_pass)"

mkdir -p /etc/pgbouncer /var/run/pgbouncer
{
    printf '"%s" "%s"\n' "${AUTH_USER}" "${AUTH_PASS}"
    printf '"repmgr" "%s"\n' "${REPMGR_PASS}"
    if [[ -n "${STORE_SPEC}" ]]; then
        IFS=',' read -ra sentries <<< "${STORE_SPEC}"
        for e in "${sentries[@]}"; do
            IFS=':' read -r scode sname sdb suser <<< "$e"
            if [[ -f "/run/secrets/odoo_db_pass_${sname}" ]]; then
                spass="$(read_secret "odoo_db_pass_${sname}")"
                printf '"%s" "%s"\n' "${suser}" "${spass}"
            fi
        done
    fi
} > /etc/pgbouncer/userlist.txt

{
    echo "[databases]"
    echo "; Pola 1: Setiap Odoo Store DB memakai session pooling terpisah (aman untuk LISTEN/NOTIFY & advisory locks)"
    if [[ -n "${STORE_SPEC}" ]]; then
        IFS=',' read -ra sentries <<< "${STORE_SPEC}"
        for e in "${sentries[@]}"; do
            IFS=':' read -r scode sname sdb suser <<< "$e"
            echo "${sdb} = host=haproxy port=${HAPROXY_RW_PORT} dbname=${sdb} pool_mode=session"
        done
    fi
    echo "; Tenant DBaaS non-Odoo memakai transaction pooling berkapasitas tinggi"
    echo "* = host=haproxy port=${HAPROXY_RW_PORT}"
    cat <<EOF_INI

[pgbouncer]
listen_addr = 0.0.0.0
listen_port = ${PGB_PORT}
auth_type = scram-sha-256
auth_file = /etc/pgbouncer/userlist.txt
auth_user = ${AUTH_USER}
auth_query = SELECT uname, phash FROM pgbouncer.user_lookup(\$1)
admin_users = repmgr, ${AUTH_USER}
stats_users = repmgr, ${AUTH_USER}
pool_mode = ${POOL_MODE}
max_client_conn = ${MAX_CLIENT_CONN}
default_pool_size = ${DEFAULT_POOL_SIZE}
reserve_pool_size = 10
server_reset_query = DISCARD ALL
ignore_startup_parameters = extra_float_digits,options
log_connections = 0
log_disconnections = 0
EOF_INI
} > /etc/pgbouncer/pgbouncer.ini

chown -R postgres:postgres /etc/pgbouncer /var/run/pgbouncer
chmod 600 /etc/pgbouncer/userlist.txt
exec su - postgres -s /bin/bash -c "exec pgbouncer /etc/pgbouncer/pgbouncer.ini"
