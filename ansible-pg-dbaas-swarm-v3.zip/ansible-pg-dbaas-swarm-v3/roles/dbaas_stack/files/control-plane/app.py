import os
import re
import hmac
import secrets
import datetime
from functools import wraps
import psycopg2
from psycopg2 import sql
import requests
from flask import Flask, request, jsonify, render_template_string, Response

app = Flask(__name__)

def read_secret(name, default=""):
    path = f"/run/secrets/{name}"
    if os.path.isfile(path):
        with open(path, "r", encoding="utf-8") as fh:
            return fh.read().strip()
    return os.environ.get(name.upper(), default)

CP_USER = os.environ.get("CP_ADMIN_USER", "admin")
CP_PASS = read_secret("cp_admin_pass", "admin")
REPMGR_PASS = read_secret("pg_repmgr_pass", "")
PGB_AUTH_USER = os.environ.get("PGBOUNCER_AUTH_USER", "pgbouncer_auth")
PG_PORT = int(os.environ.get("PG_PORT", "5432"))
HAPROXY_RW_PORT = int(os.environ.get("HAPROXY_RW_PORT", "54322"))
HAPROXY_RO_PORT = int(os.environ.get("HAPROXY_RO_PORT", "54323"))
PGBOUNCER_PORT = int(os.environ.get("PGBOUNCER_PORT", "6432"))
DB_NODES_SPEC = os.environ.get("DB_NODES_SPEC", "1:db1:100,2:db2:90")
STORE_UI_SPEC = os.environ.get("STORE_UI_SPEC", "")
ALERT_HISTORY = []

def check_auth(u, p):
    return hmac.compare_digest(u, CP_USER) and hmac.compare_digest(p, CP_PASS)

def requires_auth(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        auth = request.authorization
        if not auth or not check_auth(auth.username or "", auth.password or ""):
            return Response("Unauthorized", 401, {"WWW-Authenticate": 'Basic realm="DBaaS Control Plane"'})
        return fn(*args, **kwargs)
    return wrapper

def parse_db_nodes():
    nodes = []
    for item in DB_NODES_SPEC.split(","):
        parts = item.strip().split(":")
        if len(parts) >= 2:
            nodes.append({
                "id": parts[0],
                "name": parts[1],
                "host": f"pg_{parts[1]}",
                "priority": parts[2] if len(parts) >= 3 else "100",
            })
    return nodes

def parse_stores():
    stores = []
    for item in STORE_UI_SPEC.split(","):
        parts = item.strip().split(":")
        if len(parts) >= 5:
            stores.append({
                "code": parts[0],
                "name": parts[1],
                "port": int(parts[2]),
                "db_name": parts[3],
                "db_user": parts[4],
                "service": f"odoo_{parts[1]}",
            })
    return stores

def check_odoo_store_http(store):
    try:
        r = requests.get(f"http://{store['service']}:8069/web/health", timeout=1.5)
        return "UP" if r.status_code < 500 else f"HTTP {r.status_code}"
    except Exception:
        return "STARTING / DOWN"

def query_node_health(node):
    info = {**node, "status": "DOWN", "role": "UNREACHABLE", "lsn": "-", "connections": 0, "sync_peers": []}
    try:
        conn = psycopg2.connect(
            host=node["host"], port=PG_PORT, dbname="repmgr",
            user="repmgr", password=REPMGR_PASS, connect_timeout=2
        )
        conn.autocommit = True
        with conn.cursor() as cur:
            cur.execute("SELECT pg_is_in_recovery(), CASE WHEN pg_is_in_recovery() THEN pg_last_wal_replay_lsn()::text ELSE pg_current_wal_lsn()::text END, (SELECT count(*) FROM pg_stat_activity);")
            in_rec, lsn, conns = cur.fetchone()
            info["status"] = "UP"
            info["role"] = "STANDBY" if in_rec else "PRIMARY"
            info["lsn"] = lsn or "-"
            info["connections"] = conns
            if not in_rec:
                cur.execute("SELECT application_name, state, sync_state FROM pg_stat_replication;")
                info["sync_peers"] = [f"{r[0]} ({r[2]})" for r in cur.fetchall()]
        conn.close()
    except Exception as exc:
        info["error"] = str(exc).splitlines()[0]
    return info

def list_databases():
    dbs = []
    try:
        conn = psycopg2.connect(
            host="haproxy", port=HAPROXY_RW_PORT, dbname="postgres",
            user="repmgr", password=REPMGR_PASS, connect_timeout=3
        )
        conn.autocommit = True
        with conn.cursor() as cur:
            cur.execute("""
                SELECT d.datname, pg_catalog.pg_get_userbyid(d.datdba),
                       pg_size_pretty(pg_database_size(d.datname)),
                       (SELECT count(*) FROM pg_stat_activity a WHERE a.datname = d.datname)
                FROM pg_database d
                WHERE d.datistemplate = false
                ORDER BY d.datname;
            """)
            for r in cur.fetchall():
                dbs.append({"name": r[0], "owner": r[1], "size": r[2], "conns": r[3]})
        conn.close()
    except Exception:
        pass
    return dbs

def query_pgbouncer_pools():
    pools = []
    try:
        conn = psycopg2.connect(
            host="pgbouncer", port=PGBOUNCER_PORT, dbname="pgbouncer",
            user="repmgr", password=REPMGR_PASS, connect_timeout=2
        )
        conn.autocommit = True
        with conn.cursor() as cur:
            cur.execute("SHOW POOLS;")
            cols = [d[0] for d in cur.description]
            for row in cur.fetchall():
                pools.append(dict(zip(cols, row)))
        conn.close()
    except Exception:
        pass
    return pools

def fetch_active_alerts():
    try:
        resp = requests.get("http://alertmanager:9093/api/v2/alerts", timeout=2)
        if resp.status_code == 200:
            return resp.json()
    except Exception:
        pass
    return []

HTML_TEMPLATE = """<!doctype html>
<html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Sovereign DBaaS Control Plane (Pola 1 Multi-Store)</title>
<style>
:root{--bg:#0f172a;--card:#1e293b;--line:#334155;--text:#e2e8f0;--muted:#94a3b8;--ok:#22c55e;--warn:#f59e0b;--err:#ef4444;--acc:#38bdf8;}
*{box-sizing:border-box} body{margin:0;font-family:system-ui,-apple-system,sans-serif;background:var(--bg);color:var(--text);padding:20px}
.wrap{max-width:1280px;margin:0 auto} h1{margin:0 0 4px;font-size:24px} .sub{color:var(--muted);margin-bottom:18px;font-size:14px}
.nav{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:20px}
.nav a{background:var(--card);border:1px solid var(--line);color:var(--acc);padding:7px 12px;border-radius:8px;text-decoration:none;font-size:13px;font-weight:600}
.nav a:hover{border-color:var(--acc)} .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(380px,1fr));gap:16px;margin-bottom:16px}
.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:16px;margin-bottom:16px}
.card h2{margin:0 0 12px;font-size:16px;color:#f8fafc;border-bottom:1px solid var(--line);padding-bottom:8px}
table{width:100%;border-collapse:collapse;font-size:13px} th,td{padding:8px 6px;border-bottom:1px solid #263449;text-align:left}
th{color:var(--muted);font-weight:600} .badge{padding:3px 8px;border-radius:99px;font-size:11px;font-weight:700}
.b-pri{background:#14532d;color:#86efac} .b-stby{background:#1e3a8a;color:#93c5fd} .b-down{background:#7f1d1d;color:#fca5a5}
input,button{background:#0b1220;border:1px solid var(--line);color:var(--text);padding:8px 10px;border-radius:8px;font-size:13px}
button{background:var(--acc);color:#0f172a;font-weight:700;cursor:pointer;border:none} button:hover{opacity:.9}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px}
pre{background:#0b1220;padding:10px;border-radius:8px;overflow:auto;font-size:12px;color:#a5f3fc}
a.btn{color:var(--acc);text-decoration:none;font-weight:600}
</style></head><body><div class="wrap">
<h1>Sovereign PostgreSQL DBaaS Control Plane — Pola 1 (DB-per-Store)</h1>
<div class="sub">Docker Swarm + OpenVPN Underlay | External repmgrd Auto-Failover | PgBouncer | Barman PITR | Isolated Multi-Store Odoo 17 POS</div>
<div class="nav" id="quickLinks"></div>

<div class="card">
  <h2>1. Retail Stores Fleet (Isolated DB-per-Store: store1..storeN)</h2>
  <table><thead><tr><th>Kode</th><th>Store</th><th>Odoo Status</th><th>Isolated DB</th><th>DB Size</th><th>Active Conns</th><th>Akses POS</th></tr></thead>
  <tbody id="storesTbl"><tr><td colspan="7">Loading...</td></tr></tbody></table>
</div>

<div class="grid">
  <div class="card">
    <h2>2. PostgreSQL HA Cluster Topology (db1..dbN)</h2>
    <table><thead><tr><th>Node</th><th>Role</th><th>Status</th><th>Prio</th><th>Conns</th><th>LSN / Sync</th></tr></thead>
    <tbody id="nodesTbl"><tr><td colspan="6">Loading...</td></tr></tbody></table>
  </div>
  <div class="card">
    <h2>3. Self-Service Provision Tenant / New Store DB</h2>
    <form id="createForm">
      <div class="form-row">
        <input id="dbName" placeholder="Nama DB (mis. odoo_store4)" required pattern="[a-z][a-z0-9_]{2,40}">
        <input id="dbUser" placeholder="Username (mis. odoo_store4)" required pattern="[a-z][a-z0-9_]{2,40}">
      </div>
      <div class="form-row">
        <input id="dbConnLimit" type="number" value="50" min="5" max="500" placeholder="Max Connections">
        <button type="submit">+ Provision Isolated DB</button>
      </div>
    </form>
    <pre id="provResult">Membuat DB terisolasi (REVOKE ALL FROM PUBLIC + pgbouncer.user_lookup otomatis).</pre>
  </div>
</div>

<div class="grid">
  <div class="card">
    <h2>4. Managed Databases</h2>
    <table><thead><tr><th>Database</th><th>Owner</th><th>Size</th><th>Active Conns</th></tr></thead>
    <tbody id="dbsTbl"></tbody></table>
  </div>
  <div class="card">
    <h2>5. PgBouncer Active Pools (:6432)</h2>
    <table><thead><tr><th>Database</th><th>User</th><th>Mode</th><th>Cl Active</th><th>Sv Active</th><th>Wait</th></tr></thead>
    <tbody id="poolsTbl"></tbody></table>
  </div>
</div>

<div class="card">
  <h2>6. Active Alerts (Prometheus Alertmanager :9093)</h2>
  <pre id="alertsBox">Checking Alertmanager...</pre>
</div>
</div>
<script>
const host = window.location.hostname;
const staticLinks = [
  ["pgAdmin 4", `http://${host}:5050`],
  ["Grafana", `http://${host}:3000`],
  ["Prometheus", `http://${host}:9090`],
  ["Alertmanager", `http://${host}:9093`],
  ["Kibana (ELK)", `http://${host}:5601`],
  ["HAProxy Stats", `http://${host}:7000`]
];

async function refresh() {
  const r = await fetch("/api/status"); const d = await r.json();
  const storeLinks = d.stores.map(s => [`POS ${s.code} (${s.name})`, `http://${host}:${s.port}`]);
  document.getElementById("quickLinks").innerHTML = [...storeLinks, ...staticLinks]
    .map(([t,u])=>`<a href="${u}" target="_blank">${t} ↗</a>`).join("");

  document.getElementById("storesTbl").innerHTML = d.stores.map(s => {
    const cls = s.http_status==="UP"?"b-pri":"b-down";
    return `<tr><td><b>${s.code}</b></td><td>${s.name}</td><td><span class="badge ${cls}">${s.http_status}</span></td><td><code>${s.db_name}</code></td><td>${s.db_size}</td><td>${s.db_conns}</td><td><a class="btn" href="http://${host}:${s.port}" target="_blank">Buka :${s.port} ↗</a></td></tr>`;
  }).join("") || "<tr><td colspan='7'>Belum ada store terdaftar di STORE_NODES</td></tr>";

  document.getElementById("nodesTbl").innerHTML = d.nodes.map(n => {
    const cls = n.role==="PRIMARY"?"b-pri":(n.role==="STANDBY"?"b-stby":"b-down");
    const extra = n.sync_peers && n.sync_peers.length ? n.sync_peers.join(", ") : n.lsn;
    return `<tr><td><b>${n.name}</b> (#${n.id})</td><td><span class="badge ${cls}">${n.role}</span></td><td>${n.status}</td><td>${n.priority}</td><td>${n.connections}</td><td>${extra}</td></tr>`;
  }).join("");

  document.getElementById("dbsTbl").innerHTML = d.databases.map(x =>
    `<tr><td><b>${x.name}</b></td><td>${x.owner}</td><td>${x.size}</td><td>${x.conns}</td></tr>`
  ).join("") || "<tr><td colspan='4'>Belum terhubung ke HAProxy RW</td></tr>";

  document.getElementById("poolsTbl").innerHTML = d.pools.map(p =>
    `<tr><td>${p.database}</td><td>${p.user}</td><td>${p.pool_mode}</td><td>${p.cl_active}</td><td>${p.sv_active}</td><td>${p.cl_waiting}</td></tr>`
  ).join("") || "<tr><td colspan='6'>Belum ada pool aktif</td></tr>";

  document.getElementById("alertsBox").textContent = d.alerts.length ? JSON.stringify(d.alerts, null, 2) : "Semua sehat — nol alert aktif di Alertmanager.";
}
document.getElementById("createForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const payload = {
    db_name: document.getElementById("dbName").value.trim(),
    username: document.getElementById("dbUser").value.trim(),
    conn_limit: parseInt(document.getElementById("dbConnLimit").value, 10) || 50
  };
  const r = await fetch("/api/databases", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(payload)});
  document.getElementById("provResult").textContent = JSON.stringify(await r.json(), null, 2);
  refresh();
});
refresh(); setInterval(refresh, 8000);
</script></body></html>"""

@app.route("/")
@requires_auth
def index():
    return render_template_string(HTML_TEMPLATE)

@app.route("/api/status")
@requires_auth
def api_status():
    nodes = [query_node_health(n) for n in parse_db_nodes()]
    dbs = list_databases()
    db_map = {x["name"]: x for x in dbs}
    stores = []
    for s in parse_stores():
        dinfo = db_map.get(s["db_name"], {})
        stores.append({
            **s,
            "http_status": check_odoo_store_http(s),
            "db_size": dinfo.get("size", "-"),
            "db_conns": dinfo.get("conns", 0),
        })
    return jsonify({
        "timestamp": datetime.datetime.utcnow().isoformat() + "Z",
        "stores": stores,
        "nodes": nodes,
        "databases": dbs,
        "pools": query_pgbouncer_pools(),
        "alerts": fetch_active_alerts(),
    })

@app.route("/api/databases", methods=["POST"])
@requires_auth
def api_create_database():
    data = request.get_json(force=True, silent=True) or {}
    db_name = str(data.get("db_name", "")).strip()
    username = str(data.get("username", "")).strip()
    conn_limit = max(5, min(int(data.get("conn_limit", 50)), 500))

    ident_re = re.compile(r"^[a-z][a-z0-9_]{2,40}$")
    if not ident_re.match(db_name) or not ident_re.match(username):
        return jsonify({"error": "db_name dan username harus huruf kecil/angka/underscore (3-41 karakter)"}), 400

    gen_pass = secrets.token_urlsafe(18)
    try:
        conn = psycopg2.connect(
            host="haproxy", port=HAPROXY_RW_PORT, dbname="postgres",
            user="repmgr", password=REPMGR_PASS, connect_timeout=5
        )
        conn.autocommit = True
        with conn.cursor() as cur:
            cur.execute(
                sql.SQL("CREATE ROLE {} WITH LOGIN CREATEDB PASSWORD %s CONNECTION LIMIT %s;").format(sql.Identifier(username)),
                (gen_pass, conn_limit),
            )
            cur.execute(
                sql.SQL("CREATE DATABASE {} OWNER {} ENCODING 'UTF8';").format(sql.Identifier(db_name), sql.Identifier(username))
            )
            cur.execute(sql.SQL("REVOKE ALL ON DATABASE {} FROM PUBLIC;").format(sql.Identifier(db_name)))
            cur.execute(sql.SQL("GRANT ALL ON DATABASE {} TO {};").format(sql.Identifier(db_name), sql.Identifier(username)))
            cur.execute(sql.SQL("GRANT CONNECT ON DATABASE {} TO {};").format(sql.Identifier(db_name), sql.Identifier(PGB_AUTH_USER)))
        conn.close()

        tconn = psycopg2.connect(
            host="haproxy", port=HAPROXY_RW_PORT, dbname=db_name,
            user="repmgr", password=REPMGR_PASS, connect_timeout=5
        )
        tconn.autocommit = True
        with tconn.cursor() as cur:
            cur.execute("CREATE SCHEMA IF NOT EXISTS pgbouncer;")
            cur.execute("""
                CREATE OR REPLACE FUNCTION pgbouncer.user_lookup(in i_username text, out uname text, out phash text)
                RETURNS record AS $$
                BEGIN
                    SELECT usename, passwd FROM pg_catalog.pg_shadow WHERE usename = i_username INTO uname, phash;
                    RETURN;
                END;
                $$ LANGUAGE plpgsql SECURITY DEFINER;
            """)
            cur.execute("REVOKE ALL ON SCHEMA pgbouncer FROM PUBLIC;")
            cur.execute(sql.SQL("GRANT USAGE ON SCHEMA pgbouncer TO {};").format(sql.Identifier(PGB_AUTH_USER)))
            cur.execute(sql.SQL("GRANT EXECUTE ON FUNCTION pgbouncer.user_lookup(text) TO {};").format(sql.Identifier(PGB_AUTH_USER)))
        tconn.close()
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500

    return jsonify({
        "status": "provisioned_isolated",
        "database": db_name,
        "username": username,
        "password": gen_pass,
        "connection_limit": conn_limit,
        "endpoints": {
            "pooled_rw": f"postgresql://{username}:{gen_pass}@<SWARM_IP>:{PGBOUNCER_PORT}/{db_name}",
            "direct_rw": f"postgresql://{username}:{gen_pass}@<SWARM_IP>:{HAPROXY_RW_PORT}/{db_name}",
            "direct_ro": f"postgresql://{username}:{gen_pass}@<SWARM_IP>:{HAPROXY_RO_PORT}/{db_name}",
        },
    }), 201

@app.route("/api/alerts/webhook", methods=["POST"])
def api_alert_webhook():
    payload = request.get_json(force=True, silent=True) or {}
    ALERT_HISTORY.append({"at": datetime.datetime.utcnow().isoformat() + "Z", "payload": payload})
    del ALERT_HISTORY[:-50]
    return jsonify({"received": True}), 200

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("CP_PORT", "8080")))
