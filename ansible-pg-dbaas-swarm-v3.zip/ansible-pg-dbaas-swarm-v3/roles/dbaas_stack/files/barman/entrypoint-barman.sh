#!/usr/bin/env bash
set -euo pipefail
read_secret() { tr -d '\r\n' < "/run/secrets/$1"; }

PG_VERSION="${PG_VERSION:-15}"
PG_PORT="${PG_PORT:-5432}"
BARMAN_BACKUP_NAME="${BARMAN_BACKUP_NAME:-main_backup}"
DB_NODES_SPEC="${DB_NODES_SPEC:-1:db1:100,2:db2:90}"
PRIMARY_HOST="${PRIMARY_HOST:-pg_db1}"
HAPROXY_RW_PORT="${HAPROXY_RW_PORT:-54322}"
PGBOUNCER_AUTH_USER="${PGBOUNCER_AUTH_USER:-pgbouncer_auth}"
STORE_SPEC="${STORE_SPEC:-}"
RECONNECT_ATTEMPTS="${RECONNECT_ATTEMPTS:-6}"
RECONNECT_INTERVAL="${RECONNECT_INTERVAL:-5}"
MONITOR_INTERVAL="${MONITOR_INTERVAL:-2}"

REPMGR_PASS="$(read_secret pg_repmgr_pass)"
BARMAN_PASS="$(read_secret pg_barman_pass)"
BARMAN_STREAM_PASS="$(read_secret pg_barman_stream_pass)"

install -d -m 0700 -o postgres -g postgres /var/lib/postgresql/.ssh
install -d -m 0775 -o postgres -g postgres /var/run/repmgr /var/log/barman
printf '*:*:*:repmgr:%s\n' "${REPMGR_PASS}" > /var/lib/postgresql/.pgpass
chown postgres:postgres /var/lib/postgresql/.pgpass && chmod 600 /var/lib/postgresql/.pgpass

cp /run/secrets/repmgr_ssh_privkey /var/lib/postgresql/.ssh/id_rsa
cat > /var/lib/postgresql/.ssh/config <<'SSHC'
Host pg_*
    StrictHostKeyChecking no
    UserKnownHostsFile /dev/null
    ConnectTimeout 5
    ServerAliveInterval 10
SSHC
chown -R postgres:postgres /var/lib/postgresql/.ssh
chmod 600 /var/lib/postgresql/.ssh/id_rsa /var/lib/postgresql/.ssh/config

chown -R barman:barman /var/lib/barman /var/log/barman
printf '*:*:*:barman:%s\n*:*:*:streaming_barman:%s\n' "${BARMAN_PASS}" "${BARMAN_STREAM_PASS}" > /var/lib/barman/.pgpass
chown barman:barman /var/lib/barman/.pgpass && chmod 600 /var/lib/barman/.pgpass

cat > /etc/cron.d/barman_swarm <<CRON
* * * * * barman /usr/bin/barman cron
0 2 * * 1 barman /usr/bin/barman backup ${BARMAN_BACKUP_NAME} >> /var/log/barman/backup.log 2>&1
CRON
chmod 644 /etc/cron.d/barman_swarm

DB_NAMES=()
IFS=',' read -ra entries <<< "${DB_NODES_SPEC}"
for e in "${entries[@]}"; do
    IFS=':' read -r nid nname nprio <<< "$e"
    DB_NAMES+=("${nname}")
    cat > "/etc/repmgrd_${nname}.conf" <<RCONF
node_id=${nid}
node_name='${nname}'
conninfo='host=pg_${nname} port=${PG_PORT} user=repmgr dbname=repmgr connect_timeout=2'
data_directory='/var/lib/postgresql/data'
priority=${nprio}
failover=automatic
reconnect_attempts=${RECONNECT_ATTEMPTS}
reconnect_interval=${RECONNECT_INTERVAL}
monitor_interval_secs=${MONITOR_INTERVAL}
promote_command='ssh -o BatchMode=yes postgres@pg_${nname} /usr/lib/postgresql/${PG_VERSION}/bin/repmgr standby promote -f /etc/repmgr.conf --log-to-file'
follow_command='ssh -o BatchMode=yes postgres@pg_${nname} /usr/lib/postgresql/${PG_VERSION}/bin/repmgr standby follow -f /etc/repmgr.conf --log-to-file --upstream-node-id=%n'
service_promote_command='ssh -o BatchMode=yes postgres@pg_${nname} /usr/lib/postgresql/${PG_VERSION}/bin/pg_ctl -w -D /var/lib/postgresql/data promote'
event_notification_command='/usr/local/bin/repmgr_swarm_handler.sh %n %e'
monitoring_history=yes
log_file='/var/log/barman/repmgrd_${nname}.log'
RCONF
    chown postgres:postgres "/etc/repmgrd_${nname}.conf"
done

cron
echo "[barman-control] Menunggu Primary (${PRIMARY_HOST}:${PG_PORT}) siap..."
until su - postgres -c "pg_isready -h '${PRIMARY_HOST}' -p '${PG_PORT}' -U repmgr" >/dev/null 2>&1; do
    sleep 3
done
su - barman -c "barman receive-wal --create-slot ${BARMAN_BACKUP_NAME}" || true
su - barman -c "barman cron" || true

# 4b. Pola 1: Idempotent provisioning isolated DB-per-Store (store1..storeN) via haproxy RW
#     (Menambah storeN baru cukup update STORE_NODES + --init-secrets + --deploy -> NOL restart PostgreSQL!)
if [[ -n "${STORE_SPEC}" ]]; then
    echo "[barman-control] Memastikan database terisolasi Pola 1 tersedia di Primary aktif..."
    until su - postgres -c "pg_isready -h haproxy -p '${HAPROXY_RW_PORT}' -U repmgr" >/dev/null 2>&1; do
        sleep 3
    done
    IFS=',' read -ra sentries <<< "${STORE_SPEC}"
    for e in "${sentries[@]}"; do
        IFS=':' read -r scode sname sdb suser <<< "$e"
        if [[ -f "/run/secrets/odoo_db_pass_${sname}" ]]; then
            spass="$(read_secret "odoo_db_pass_${sname}")"
            echo "[barman-control] Ensuring store DB '${sdb}' (user '${suser}', code '${scode}')..."
            su - postgres -c "psql -h haproxy -p '${HAPROXY_RW_PORT}' -U repmgr -d postgres" <<SQL
DO \$\$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '${suser}') THEN
    EXECUTE format('CREATE USER %I WITH LOGIN CREATEDB PASSWORD %L', '${suser}', '${spass}');
  END IF;
END
\$\$;
SQL
            DB_EX=$(runuser -u postgres -- psql -h haproxy -p "${HAPROXY_RW_PORT}" -U repmgr -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname='${sdb}';")
            if [[ "${DB_EX}" != "1" ]]; then
                runuser -u postgres -- psql -h haproxy -p "${HAPROXY_RW_PORT}" -U repmgr -d postgres -c "CREATE DATABASE \"${sdb}\" OWNER \"${suser}\" ENCODING 'UTF8';"
            fi
            su - postgres -c "psql -h haproxy -p '${HAPROXY_RW_PORT}' -U repmgr -d postgres" <<SQL
REVOKE ALL ON DATABASE "${sdb}" FROM PUBLIC;
GRANT ALL ON DATABASE "${sdb}" TO "${suser}";
GRANT CONNECT ON DATABASE "${sdb}" TO ${PGBOUNCER_AUTH_USER};
SQL
            su - postgres -c "psql -h haproxy -p '${HAPROXY_RW_PORT}' -U repmgr -d '${sdb}'" <<SQL
CREATE SCHEMA IF NOT EXISTS pgbouncer AUTHORIZATION postgres;
CREATE OR REPLACE FUNCTION pgbouncer.user_lookup(in i_username text, out uname text, out phash text)
RETURNS record AS \$\$
BEGIN
  SELECT usename, passwd FROM pg_catalog.pg_shadow WHERE usename = i_username INTO uname, phash;
  RETURN;
END;
\$\$ LANGUAGE plpgsql SECURITY DEFINER;
REVOKE ALL ON SCHEMA pgbouncer FROM PUBLIC;
GRANT USAGE ON SCHEMA pgbouncer TO ${PGBOUNCER_AUTH_USER};
GRANT EXECUTE ON FUNCTION pgbouncer.user_lookup(text) TO ${PGBOUNCER_AUTH_USER};
SQL
        fi
    done
fi

echo "[barman-control] Mengaktifkan daemon auto-failover repmgrd untuk: ${DB_NAMES[*]}"
while true; do
    for nname in "${DB_NAMES[@]}"; do
        pidf="/var/run/repmgr/repmgrd_${nname}.pid"
        if [[ ! -f "$pidf" ]] || ! kill -0 "$(cat "$pidf" 2>/dev/null || echo 0)" 2>/dev/null; then
            su - postgres -c "/usr/lib/postgresql/${PG_VERSION}/bin/repmgrd -d --config-file /etc/repmgrd_${nname}.conf --pid-file=${pidf}" || true
        fi
    done
    sleep 10
done
