#!/usr/bin/env bash
set -euo pipefail

read_secret() { tr -d '\r\n' < "/run/secrets/$1"; }

STORE_CODE="${STORE_CODE:-STR01}"
STORE_NAME="${STORE_NAME:-store1}"
ODOO_DB_HOST="${ODOO_DB_HOST:-pgbouncer}"
ODOO_DB_PORT="${ODOO_DB_PORT:-6432}"
ODOO_DB_NAME="${ODOO_DB_NAME:-odoo_store1}"
ODOO_DB_USER="${ODOO_DB_USER:-odoo_store1}"
ODOO_AUTO_INIT="${ODOO_AUTO_INIT:-1}"
ODOO_WORKERS="${ODOO_WORKERS:-2}"

ODOO_MASTER_PASS="$(read_secret odoo_master_pass)"
ODOO_DB_PASS="$(read_secret odoo_db_pass)"

chown -R odoo:odoo /var/lib/odoo /mnt/extra-addons
cat > /tmp/odoo.conf <<CONF
[options]
addons_path = /mnt/extra-addons
data_dir = /var/lib/odoo
admin_passwd = ${ODOO_MASTER_PASS}
db_host = ${ODOO_DB_HOST}
db_port = ${ODOO_DB_PORT}
db_user = ${ODOO_DB_USER}
db_password = ${ODOO_DB_PASS}
db_name = ${ODOO_DB_NAME}
dbfilter = ^${ODOO_DB_NAME}\$
list_db = False
proxy_mode = True
workers = ${ODOO_WORKERS}
max_cron_threads = 1
limit_time_cpu = 120
limit_time_real = 240
CONF
chown odoo:odoo /tmp/odoo.conf && chmod 600 /tmp/odoo.conf

echo "[odoo-${STORE_NAME}] Menunggu DB terisolasi '${ODOO_DB_NAME}' via ${ODOO_DB_HOST}:${ODOO_DB_PORT}..."
until PGPASSWORD="${ODOO_DB_PASS}" psql -h "${ODOO_DB_HOST}" -p "${ODOO_DB_PORT}" -U "${ODOO_DB_USER}" -d "${ODOO_DB_NAME}" -c "SELECT 1;" >/dev/null 2>&1; do
    sleep 4
done

if [[ "${ODOO_AUTO_INIT}" == "1" ]]; then
    HAS_MOD=$(PGPASSWORD="${ODOO_DB_PASS}" psql -h "${ODOO_DB_HOST}" -p "${ODOO_DB_PORT}" -U "${ODOO_DB_USER}" -d "${ODOO_DB_NAME}" -tAc \
        "SELECT 1 FROM information_schema.tables WHERE table_name='ir_module_module';" 2>/dev/null || echo "")
    if [[ "${HAS_MOD}" != "1" ]]; then
        echo "[odoo-${STORE_NAME}] Inisialisasi awal '${ODOO_DB_NAME}' + POS & addon retail_store_pos..."
        runuser -u odoo -- odoo -c /tmp/odoo.conf -d "${ODOO_DB_NAME}" \
            -i base,point_of_sale,sale_management,stock,account,retail_store_pos \
            --without-demo=all --stop-after-init

        # Seed profil cabang default milik store ini secara otomatis
        PGPASSWORD="${ODOO_DB_PASS}" psql -h "${ODOO_DB_HOST}" -p "${ODOO_DB_PORT}" -U "${ODOO_DB_USER}" -d "${ODOO_DB_NAME}" <<SQL || true
INSERT INTO retail_store_branch (code, name, active, currency_id, create_uid, write_uid, create_date, write_date)
SELECT '${STORE_CODE}', 'Outlet ${STORE_NAME^^} (${STORE_CODE})', true,
       (SELECT currency_id FROM res_company ORDER BY id ASC LIMIT 1), 1, 1, NOW(), NOW()
ON CONFLICT (code) DO NOTHING;
SQL
    fi
fi

exec runuser -u odoo -- odoo -c /tmp/odoo.conf
