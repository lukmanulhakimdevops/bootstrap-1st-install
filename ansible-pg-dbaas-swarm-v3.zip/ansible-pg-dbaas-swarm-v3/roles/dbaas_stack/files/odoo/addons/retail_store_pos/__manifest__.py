{
    "name": "Retail Store & POS Management (Pola 1 Isolated)",
    "version": "17.0.1.0.0",
    "category": "Point of Sale",
    "summary": "Manajemen toko retail terisolasi (DB-per-Store) terintegrasi POS, Inventory, Sales & Invoicing",
    "author": "Sovereign DBaaS Team",
    "license": "LGPL-3",
    "depends": ["base", "point_of_sale", "sale_management", "stock", "account"],
    "data": [
        "security/ir.model.access.csv",
        "views/retail_store_views.xml",
    ],
    "installable": True,
    "application": True,
}
