from odoo import api, fields, models


class RetailStoreBranch(models.Model):
    _name = "retail.store.branch"
    _description = "Retail Store Branch / Outlet"
    _order = "code asc, name asc"

    code = fields.Char(string="Kode Cabang", required=True, index=True)
    name = fields.Char(string="Nama Toko / Outlet", required=True)
    street = fields.Char(string="Alamat")
    city = fields.Char(string="Kota")
    phone = fields.Char(string="Telepon")
    active = fields.Boolean(default=True)
    manager_id = fields.Many2one("res.users", string="Store Manager")
    warehouse_id = fields.Many2one("stock.warehouse", string="Gudang Cabang")
    currency_id = fields.Many2one(
        "res.currency",
        default=lambda self: self.env.company.currency_id.id,
        readonly=True,
    )
    daily_sales_target = fields.Monetary(string="Target Penjualan Harian", currency_field="currency_id")
    pos_config_ids = fields.One2many("pos.config", "retail_branch_id", string="Kasir / POS Terminals")
    pos_count = fields.Integer(string="Jumlah Kasir", compute="_compute_branch_metrics")
    today_sales_total = fields.Monetary(
        string="Omzet Hari Ini",
        currency_field="currency_id",
        compute="_compute_branch_metrics",
    )

    _sql_constraints = [
        ("code_uniq", "unique(code)", "Kode cabang retail harus unik!"),
    ]

    @api.depends("pos_config_ids")
    def _compute_branch_metrics(self):
        today = fields.Date.context_today(self)
        start_dt = fields.Datetime.to_string(fields.Datetime.from_string(f"{today} 00:00:00"))
        PosOrder = self.env["pos.order"]
        for rec in self:
            rec.pos_count = len(rec.pos_config_ids)
            if rec.pos_config_ids:
                orders = PosOrder.search([
                    ("config_id", "in", rec.pos_config_ids.ids),
                    ("date_order", ">=", start_dt),
                    ("state", "in", ["paid", "done", "invoiced"]),
                ])
                rec.today_sales_total = sum(orders.mapped("amount_total"))
            else:
                rec.today_sales_total = 0.0


class PosConfig(models.Model):
    _inherit = "pos.config"

    retail_branch_id = fields.Many2one("retail.store.branch", string="Cabang Toko Retail")
    retail_branch_code = fields.Char(related="retail_branch_id.code", string="Kode Cabang", store=True)
