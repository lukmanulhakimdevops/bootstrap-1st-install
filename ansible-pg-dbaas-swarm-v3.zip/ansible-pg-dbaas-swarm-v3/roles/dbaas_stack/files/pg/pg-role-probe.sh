#!/usr/bin/env bash
set -euo pipefail
PG_PORT="${PG_PORT:-5432}"
IN_REC=$(su - postgres -c "psql -h 127.0.0.1 -p ${PG_PORT} -tAc 'SELECT pg_is_in_recovery();'" 2>/dev/null || echo "err")
if [[ "${IN_REC}" == "f" ]]; then
    printf "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 8\r\n\r\nPRIMARY\n"
elif [[ "${IN_REC}" == "t" ]]; then
    printf "HTTP/1.1 206 Partial Content\r\nContent-Type: text/plain\r\nContent-Length: 8\r\n\r\nSTANDBY\n"
else
    printf "HTTP/1.1 503 Service Unavailable\r\nContent-Type: text/plain\r\nContent-Length: 5\r\n\r\nDOWN\n"
fi
