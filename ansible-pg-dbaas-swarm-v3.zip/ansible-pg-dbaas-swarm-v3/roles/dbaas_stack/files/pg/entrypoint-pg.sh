#!/usr/bin/env bash
set -euo pipefail

read_secret() {
    local f="/run/secrets/$1"
    [[ -f "$f" ]] || { echo "Secret missing: $f" >&2; exit 1; }
    tr -d '\r\n' < "$f"
}

PGDATA="${PGDATA:-/var/lib/postgresql/data}"
PG_PORT="${PG_PORT:-5432}"
PG_CHECK_PORT="${PG_CHECK_PORT:-9201}"
NODE_NAME="${NODE_NAME:-db1}"
IS_PRIMARY="${IS_PRIMARY:-false}"
PRIMARY_HOST="${PRIMARY_HOST:-pg_db1}"
PG_MON_USER="${PG_MON_USER:-pg_exporter}"
PGBOUNCER_AUTH_USER="${PGBOUNCER_AUTH_USER:-pgbouncer_auth}"

POSTGRES_SUPER_PASS="$(read_secret pg_super_pass)"
REPMGR_PASS="$(read_secret pg_repmgr_pass)"
BARMAN_PASS="$(read_secret pg_barman_pass)"
BARMAN_STREAM_PASS="$(read_secret pg_barman_stream_pass)"
PG_MON_PASS="$(read_secret pg_mon_pass)"
PGBOUNCER_AUTH_PASS="$(read_secret pg_pgbouncer_pass)"

chown -R postgres:postgres "${PGDATA}" /var/log/postgresql
chmod 700 "${PGDATA}"

printf '*:*:*:repmgr:%s\n' "${REPMGR_PASS}" > /var/lib/postgresql/.pgpass
chown postgres:postgres /var/lib/postgresql/.pgpass
chmod 600 /var/lib/postgresql/.pgpass

if [[ -f /run/secrets/repmgr_ssh_pubkey ]]; then
    install -d -m 0700 -o postgres -g postgres /var/lib/postgresql/.ssh
    cp /run/secrets/repmgr_ssh_pubkey /var/lib/postgresql/.ssh/authorized_keys
    chown postgres:postgres /var/lib/postgresql/.ssh/authorized_keys
    chmod 600 /var/lib/postgresql/.ssh/authorized_keys
fi

/usr/sbin/sshd -o PasswordAuthentication=no -o PubkeyAuthentication=yes -o AllowUsers=postgres || true
socat "TCP-LISTEN:${PG_CHECK_PORT},crlf,reuseaddr,fork" "EXEC:/usr/local/bin/pg-role-probe.sh" &

install_pgbouncer_lookup() {
    local target_db=$1
    su - postgres -c "psql -p ${PG_PORT} -d '${target_db}'" <<SQL
CREATE SCHEMA IF NOT EXISTS pgbouncer AUTHORIZATION postgres;
CREATE OR REPLACE FUNCTION pgbouncer.user_lookup(in i_username text, out uname text, out phash text)
RETURNS record AS \$\$
BEGIN
    SELECT usename, passwd FROM pg_catalog.pg_shadow WHERE usename = i_username INTO uname, phash;
    RETURN;
END;
\$\$ LANGUAGE plpgsql SECURITY DEFINER;
REVOKE ALL ON SCHEMA pgbouncer FROM PUBLIC;
REVOKE ALL ON FUNCTION pgbouncer.user_lookup(text) FROM PUBLIC;
GRANT USAGE ON SCHEMA pgbouncer TO ${PGBOUNCER_AUTH_USER};
GRANT EXECUTE ON FUNCTION pgbouncer.user_lookup(text) TO ${PGBOUNCER_AUTH_USER};
SQL
}

if [[ ! -s "${PGDATA}/PG_VERSION" ]]; then
    if [[ "${IS_PRIMARY}" == "true" ]]; then
        echo "[${NODE_NAME}] Inisialisasi PRIMARY + Pola 1 Isolated DB-per-Store..."
        su - postgres -c "/usr/lib/postgresql/${PG_MAJOR}/bin/initdb -D '${PGDATA}' --encoding=UTF8 --auth-host=${PG_AUTH_METHOD:-scram-sha-256}"
        su - postgres -c "/usr/lib/postgresql/${PG_MAJOR}/bin/pg_ctl -D '${PGDATA}' -o \"-c config_file=/etc/postgresql/postgresql.ha.conf -c hba_file=/etc/postgresql/pg_hba.conf\" -w start"

        su - postgres -c "psql -p ${PG_PORT}" <<SQL
ALTER USER postgres WITH PASSWORD '${POSTGRES_SUPER_PASS}';
CREATE USER repmgr WITH SUPERUSER REPLICATION PASSWORD '${REPMGR_PASS}';
CREATE DATABASE repmgr OWNER repmgr;
ALTER USER repmgr SET search_path TO repmgr, "\$user", public;
CREATE USER barman WITH SUPERUSER PASSWORD '${BARMAN_PASS}';
CREATE USER streaming_barman WITH REPLICATION PASSWORD '${BARMAN_STREAM_PASS}';
CREATE USER ${PG_MON_USER} WITH PASSWORD '${PG_MON_PASS}';
GRANT pg_monitor TO ${PG_MON_USER};
CREATE USER ${PGBOUNCER_AUTH_USER} WITH PASSWORD '${PGBOUNCER_AUTH_PASS}';
SQL
        install_pgbouncer_lookup "postgres"

        # Store DBs (store1..storeN) diprovision otomatis & idempoten oleh barman_control -> zero PG restart saat tambah toko!

        su - postgres -c "repmgr -f /etc/repmgr.conf primary register --force"
        su - postgres -c "/usr/lib/postgresql/${PG_MAJOR}/bin/pg_ctl -D '${PGDATA}' -m fast -w stop"
    else
        echo "[${NODE_NAME}] Menunggu PRIMARY (${PRIMARY_HOST}:${PG_PORT}) siap sebelum standby clone..."
        until su - postgres -c "pg_isready -h '${PRIMARY_HOST}' -p '${PG_PORT}' -U repmgr" >/dev/null 2>&1; do
            sleep 3
        done
        su - postgres -c "repmgr -h '${PRIMARY_HOST}' -p '${PG_PORT}' -U repmgr -d repmgr -f /etc/repmgr.conf standby clone -F"
        su - postgres -c "/usr/lib/postgresql/${PG_MAJOR}/bin/pg_ctl -D '${PGDATA}' -o \"-c config_file=/etc/postgresql/postgresql.ha.conf -c hba_file=/etc/postgresql/pg_hba.conf\" -w start"
        su - postgres -c "repmgr -f /etc/repmgr.conf standby register --force"
        su - postgres -c "/usr/lib/postgresql/${PG_MAJOR}/bin/pg_ctl -D '${PGDATA}' -m fast -w stop"
    fi
fi

exec gosu postgres postgres \
    -D "${PGDATA}" \
    -c config_file=/etc/postgresql/postgresql.ha.conf \
    -c hba_file=/etc/postgresql/pg_hba.conf
