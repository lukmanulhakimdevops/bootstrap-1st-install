# Ansible Sovereign PostgreSQL DBaaS v3 (Docker Swarm + OpenVPN + Pola 1 Multi-Store Odoo 17)

Versi **Ansible modular** penuh dari `pg-dbaas-swarm-ovpn-v3.sh` — 100% otomasi dari satu Control Node tanpa `scp` file `.ovpn` manual, tanpa *copy-paste* `docker swarm join-token`, tanpa `iptables` NAT, dan tanpa *password* polos di YAML.

## Arsitektur 6 Stage (`site.yml`)
1. **`prereq_node`**: Prasyarat Ansible Managed Node (`python3-apt`, `acl`), `chrony`, kernel `sysctl`, Docker Engine + `daemon.json` (`nofile=65536`, `memlock=-1`, log rotation), dan direktori persisten `db1..dbN` + `odoo-filestore/store1..storeN`.
2. **`openvpn_hub`** (`backup`): Generate CA, server cert, `tls-crypt`, CCD static VPN IP, & profil `.ovpn` untuk seluruh node (`AES-256-GCM`, `float`, `tun-mtu 1400`).
3. **`openvpn_client`** (`all:!backup`): Otomatis `slurp` `.ovpn` dari `backup`, pasang ke `/etc/openvpn/client/pg-dbaas.conf`, & verifikasi konektivitas `tun0`.
4. **`swarm_cluster`**: `docker swarm init` & `join` otomatis terikat ke `vpn_ip` (`--advertise-addr` + `--data-path-addr`), plus *auto-labeling* (`pg_node=dbN`, `role=backup/monitoring/app`, `store_<store>=true`).
5. **`swarm_secrets`**: Membuat 12+ Docker Secrets (termasuk `odoo_db_pass_<store>` unik per toko & SSH keypair auto-failover `repmgrd`) secara idempoten (*append-only* ke `/root/.pgdbaas_credentials.txt`, atau *override* via Ansible Vault).
6. **`dbaas_stack`**: Build 5 *image* kustom (PG+repmgr, Barman+external `repmgrd`, PgBouncer, Flask Control Plane Web UI, Odoo 17 + `retail_store_pos`), render `docker-stack.yml` (MTU `1300`, Pola 1 DB-per-Store), dan eksekusi `docker stack deploy`.

## Cara Eksekusi Cepat

```bash
unzip ansible-pg-dbaas-swarm-v3.zip && cd ansible-pg-dbaas-swarm-v3

# 1. Pasang prasyarat Ansible Control Node (sekali saja)
chmod +x bootstrap-ansible-prereq.sh
./bootstrap-ansible-prereq.sh

# 2. Edit IP & endpoint OpenVPN Hub
nano inventory/hosts.yml
nano inventory/group_vars/all.yml

# 3. (Opsional) Enkripsi kredensial sendiri lewat Ansible Vault
#    (jika dilewati, password 24-karakter acak otomatis dibuat di /root/.pgdbaas_credentials.txt)
ansible-vault create inventory/group_vars/vault.yml

# 4. Uji SSH ke semua node & jalankan deployment penuh!
ansible all -m ping
ansible-playbook site.yml
# Atau dengan Vault:
# ansible-playbook site.yml --ask-vault-pass
```

## Operasi Day-2

* **Tambah Toko Baru (`store4..storeN`) Tanpa Restart PostgreSQL:**
  Tambahkan entri baru pada `store_nodes:` di `inventory/group_vars/all.yml`, lalu jalankan:
  ```bash
  ansible-playbook add_store.yml
  ```
* **Promosi Standby Manual:**
  ```bash
  ansible-playbook promote.yml -e target_db=db2
  ```
* **Cek Kesehatan OpenVPN (`tun0`) & Docker Swarm:**
  ```bash
  ansible-playbook status.yml
  ```
* **Jalankan Tahap Tertentu Saja (`--tags`):**
  ```bash
  ansible-playbook site.yml --tags prereq_node
  ansible-playbook site.yml --tags openvpn
  ansible-playbook site.yml --tags swarm_cluster,swarm_secrets
  ansible-playbook site.yml --tags deploy
  ```
