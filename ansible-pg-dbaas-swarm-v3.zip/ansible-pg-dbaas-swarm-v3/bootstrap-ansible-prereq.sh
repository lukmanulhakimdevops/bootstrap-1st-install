#!/usr/bin/env bash
# =============================================================================
# bootstrap-ansible-prereq.sh — Pasang Prasyarat Ansible Control Node
# Jalankan sekali di laptop / bastion / control node (Debian/Ubuntu).
# =============================================================================
set -euo pipefail

echo "[1/4] Memasang paket Python, pip, sshpass, & Ansible..."
sudo DEBIAN_FRONTEND=noninteractive apt-get update -qq
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
  python3 python3-pip python3-venv sshpass openssh-client git curl

if ! command -v ansible-playbook >/dev/null 2>&1; then
  sudo DEBIAN_FRONTEND=noninteractive apt-get install -y -qq ansible \
    || pip3 install --break-system-packages ansible-core
fi

echo "[2/4] Memasang Ansible Galaxy collections (community.docker, general, posix)..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ansible-galaxy collection install -r "${SCRIPT_DIR}/requirements.yml" --force

echo "[3/4] Menyiapkan SSH keypair default (~/.ssh/id_ed25519) jika belum ada..."
if [[ ! -f "${HOME}/.ssh/id_ed25519" && ! -f "${HOME}/.ssh/id_rsa" ]]; then
  ssh-keygen -q -t ed25519 -N "" -C "ansible-dbaas@$(hostname -s)" -f "${HOME}/.ssh/id_ed25519"
fi

echo "[4/4] Verifikasi Ansible:"
ansible --version
echo ""
echo "Selesai! Langkah berikut:"
echo "  1. Salin SSH key ke semua node: ssh-copy-id root@<ip_node>"
echo "  2. Edit inventory/hosts.yml & inventory/group_vars/all.yml"
echo "  3. Uji koneksi: ansible all -m ping"
echo "  4. Deploy seluruh DBaaS Stack (OpenVPN + Swarm + Secrets + Pola 1 Odoo): ansible-playbook site.yml"
